# wasm-fuzz-corpus
A set of wasm files useful to bootstrap a fuzzer
